kill @e[type=slime]
